import logo from './logo.svg';
import './App.css';
import C1 from './components/C1';

function App() {
  return (
    <div className="App">
      <C1 />
    </div>
  );
}

export default App;
